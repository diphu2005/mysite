HOW TO EDIT & HOST (Quick Guide)

FILES
- index.html  -> Your actual page. Open in any browser to preview.
- styles.css  -> Change colors, fonts, layout.
- (optional) You can add images to the same folder and reference them in index.html.

EDITING
1) Open index.html in a text editor (VS Code, Notepad++, or even Notepad).
2) Change "Your Event Name", date/time, location, and the registration link.
3) Save.

HOSTING — OPTION A: NETLIFY DROP (fastest)
1) Go to https://app.netlify.com/drop
2) Drag-and-drop this entire folder OR upload a ZIP of it.
3) You’ll get a public URL immediately. Share it.

HOSTING — OPTION B: GITHUB PAGES (reliable & free)
1) Create a GitHub account at https://github.com (if you don’t have one).
2) Click “+” > “New repository”. Name it e.g., my-site.
3) Upload index.html and styles.css to the repo (drag-and-drop in the browser).
4) Go to Settings > Pages > Select “Deploy from a branch”.
5) Choose branch “main” and folder “/ (root)”, then “Save”.
6) Wait 1 minute; your site will be live at https://YOUR-USERNAME.github.io/my-site

HOSTING — OPTION C: InfinityFree (free subdomain)
1) Create an account and a free subdomain.
2) Open File Manager for your site; go to htdocs/.
3) Upload index.html and styles.css (do NOT keep them inside an extra folder).
4) If you upload a ZIP, click EXTRACT inside File Manager, then ensure files end up directly in htdocs/.
5) Open your subdomain URL to see the site.

TIPS
- If you only upload index.html, it will still work (but without the separate CSS).
- You can edit files and simply re-upload to update your site.
